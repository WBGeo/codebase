"""Interactive visualization utilities for WBGeo hierarchical meshes.

The main plot uses two linked PyVista subplots: mesh 1 (outer/coarse) on the
left and mesh 2 (inner/fine) on the right.  It follows the colour/legend logic
of ``meshing_visualization.py`` while keeping surface-only blocks visible so
hierarchical engineering objects (extra planes, ellipses and triangulations)
can also be inspected.
"""

import logging
import warnings
from typing import List, Tuple

import numpy as np
import pyvista as pv

from core.object_components import MeshResults, StructuralModelResults
from py_api_wbgeo.nodesapi import wbgeo_component, wbgeo_inspector, InspectorHelper

logger = logging.getLogger(__name__)

_FALLBACK_COLORS = [
    '#673ab7', '#34a853', '#ea4335', '#fbbc05', '#4285f4',
    '#c4e4fc', '#ffd4d4', '#fff4c2', '#c4f8bd',
    '#f18d00', '#bbdaa4', '#a7cdf2', '#9bbff4', '#4a80f5',
]


def _labels_and_colors(
    geomodel_result: StructuralModelResults,
) -> Tuple[List[str], List[str]]:
    """Build the same lithology labels/colours used by plot_mesh_3d()."""
    labels_fwd: List[str] = []
    colors_fwd: List[str] = []

    idx = 0
    for group in geomodel_result.structural_frame.structural_groups:
        for elem in group.structural_elements:
            labels_fwd.append(elem.name)
            colors_fwd.append(
                elem.color
                if elem.color is not None
                else _FALLBACK_COLORS[idx % len(_FALLBACK_COLORS)]
            )
            idx += 1

    return (
        ["basement"] + list(reversed(labels_fwd)),
        ["#808080"] + list(reversed(colors_fwd)),
    )


def _block_name(multiblock: pv.MultiBlock, index: int) -> str:
    """Return a useful block name without depending on a PyVista version."""
    try:
        name = multiblock.get_block_name(index)
        if name:
            return str(name)
    except Exception:
        pass
    return f"Block {index}"


def _is_surface_only(block) -> bool:
    """True for PolyData or datasets containing only VTK triangle cells."""
    if isinstance(block, pv.PolyData):
        return True
    try:
        cell_types = np.unique(block.celltypes)
        return len(cell_types) == 1 and cell_types[0] == 5  # VTK_TRIANGLE
    except Exception:
        return False


def _add_mesh_to_subplot(
    plotter: pv.Plotter,
    mesh_results: MeshResults,
    geomodel_result: StructuralModelResults,
    row: int,
    col: int,
    title: str,
    style: str,
    show_surface_blocks: bool,
    omit_last_blocks: int,
) -> None:
    """Add one MeshResults object to one subplot."""
    plotter.subplot(row, col)

    labels, colors = _labels_and_colors(geomodel_result)
    mesh = mesh_results.mesh
    legend_entries = []

    # The final blocks in WBGeo MeshResults are auxiliary/object blocks that
    # should not be drawn in the hierarchical lithology comparison.
    stop = max(0, mesh.n_blocks - omit_last_blocks)

    for i in range(stop):
        block = mesh[i]
        if block is None or getattr(block, "n_cells", 0) == 0:
            continue

        surface_only = _is_surface_only(block)
        if surface_only and not show_surface_blocks:
            continue

        block_name = _block_name(mesh, i)

        # Preserve the normal meshing_visualization lithology colours for the
        # first blocks. Extra engineering-object blocks receive fallback colours.
        color = (
            colors[i]
            if i < len(colors)
            else _FALLBACK_COLORS[i % len(_FALLBACK_COLORS)]
        )
        label = labels[i] if i < len(labels) else block_name

        # Surface engineering objects are easiest to see as opaque surfaces;
        # volumetric blocks honour the requested PyVista style.
        block_style = "surface" if surface_only else style

        plotter.add_mesh(
            block,
            show_edges=True,
            style=block_style,
            color=color,
            label=label,
        )
        legend_entries.append([label, color])

    plotter.add_text(title, position="upper_edge", font_size=12)
    plotter.show_bounds(grid=True)

    if legend_entries:
        # Remove duplicate labels while preserving order.
        unique_entries = []
        seen = set()
        for label, color in legend_entries:
            if label in seen:
                continue
            seen.add(label)
            unique_entries.append([label, color])
        plotter.add_legend(
            unique_entries,
            size=(0.18, 0.18),
            loc="lower right",
            face="circle",
        )


def plot_hierarchical_meshes_3d(
    mesh1: MeshResults,
    mesh2: MeshResults,
    geomodel_result: StructuralModelResults,
    style: str = "surface",
    show_plotter: bool = True,
    show_surface_blocks: bool = True,
    link_views: bool = True,
    omit_last_blocks: int = 6,
) -> pv.Plotter:
    """Interactively plot a pair of hierarchical meshes side by side.

    Parameters
    ----------
    mesh1, mesh2
        Outer/coarse and inner/fine hierarchical ``MeshResults``.
    geomodel_result
        Structural model result used for lithology labels and colours.
    style
        PyVista style for volumetric blocks: ``surface``, ``wireframe`` or
        ``points``.
    show_plotter
        Display the interactive PyVista window when True.
    show_surface_blocks
        Keep triangle/PolyData blocks visible.  This defaults to True because
        hierarchical engineering objects such as extra planes, ellipses and
        triangulations can be represented by surface blocks.
    link_views
        Link both subplot cameras so rotate/zoom/pan is synchronized.
    omit_last_blocks
        Number of blocks at the end of each MeshResults MultiBlock to skip.
        Defaults to 6 for the hierarchical WBGeo mesh layout.

    Returns
    -------
    pyvista.Plotter
        Configured plotter, useful for further customization or tests.
    """
    warnings.filterwarnings(
        "ignore",
        message="Points is not a float type. This can cause issues when transforming or applying "
                "filters. Casting to ``np.float32``. Disable this by passing "
                "``force_float=False``.",
    )

    if style not in {"surface", "wireframe", "points"}:
        raise ValueError("style must be 'surface', 'wireframe', or 'points'.")

    plotter = pv.Plotter(shape=(1, 2), off_screen=not show_plotter)

    _add_mesh_to_subplot(
        plotter, mesh1, geomodel_result, 0, 0,
        "Hierarchical mesh 1 (outer / coarse)", style, show_surface_blocks, omit_last_blocks,
    )
    _add_mesh_to_subplot(
        plotter, mesh2, geomodel_result, 0, 1,
        "Hierarchical mesh 2 (inner / fine)", style, show_surface_blocks, omit_last_blocks,
    )

    if link_views:
        plotter.link_views()

    # Start both subplots from the same camera orientation.
    for row, col in ((0, 0), (0, 1)):
        plotter.subplot(row, col)
        plotter.camera.view_angle = 30.0
        plotter.camera.azimuth = 25.0
        plotter.camera.elevation = -15.0

    plotter.subplot(0, 0)

    if show_plotter:
        plotter.show()

    return plotter


@wbgeo_component(
    identifier='wbgeo::inspect_hierarchical_meshes_3d',
    title='Plot Hierarchical Meshes in 3D',
    description='Interactively inspect the outer/coarse and inner/fine hierarchical meshes side by side.',
)
@wbgeo_inspector()
async def inspect_hierarchical_meshes_3d(
    mesh1: MeshResults,
    mesh2: MeshResults,
    _inspector: InspectorHelper,
):
    """WBGeo inspector for a hierarchical mesh pair."""
    structural_model_result = await (
        await _inspector.trace(StructuralModelResults)
    ).get_value()

    plot_hierarchical_meshes_3d(
        mesh1,
        mesh2,
        structural_model_result,
        style="surface",
        show_plotter=True,
        show_surface_blocks=True,
        link_views=True,
        omit_last_blocks=6,
    )
